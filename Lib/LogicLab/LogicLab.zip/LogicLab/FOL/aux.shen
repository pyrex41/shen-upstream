(package fol (fol-external-symbols)

(define exchange
  {number --> number --> (list A) --> (list A)}
   M N X -> (exchange-h M N X)   where (and (integer? M)
                                            (> M 0)
                                            (integer? N)
                                            (> N 0)
                                            (>= (length X) M)
                                            (>= (length X) N))
   _ _ X -> X)

(define exchange-h 
  {number --> number --> (list A) --> (list A)}
   M N X -> X     where (or (= M 0) (= N 0))
   M N X -> X     where (or (> M (length X)) (> N (length X)))
   1 N [X | Y] -> (let Z (nth N [X | Y])
                            [Z | (insert-nth X (- N 1) Y)])
   M 1 [X | Y] -> (let Z (nth M [X | Y])
                            [Z | (insert-nth X (- M 1) Y)])
   M N [X | Y] -> [X | (exchange-h (- M 1) (- N 1) Y)])

(define remove-nth
  {number --> (list A) --> (list A)}
  N X -> X  	where (not (natural? N))
  _ [] -> []
  1 [_ | Y] -> Y
  N [X | Y] -> [X | (remove-nth (- N 1) Y)])

(define insert-nth
  {A --> number --> (list A) --> (list A)}
   X 1 [_ | Y] -> [X | Y]
   X N [Y | Z] -> [Y | (insert-nth X (- N 1) Z)])
   
(define fresh?
  {A --> B --> boolean}
  X Y -> (= (occurrences X Y) 0)) 

(define atomic?
   {prop --> boolean}
    X -> (every? (/. Y (fresh? Y X)) [v ~ => <=> & all exists =]))   
  
(define replace
   {variable --> term --> prop --> prop}
  X T [all X P] -> [all X P]
  X T [exists X P] -> [exists X P]
  X T [all Y P]  -> [all Y (replace X T P)]
  X T [exists Y P] -> [exists Y (replace X T P)]
  X T [~ P] -> [~ (replace X T P)]
  X T [P v Q] -> [(replace X T P) v (replace X T Q)]
  X T [P & Q] -> [(replace X T P) & (replace X T Q)]
  X T [P => Q] -> [(replace X T P) => (replace X T Q)]
  X T [P <=> Q] -> [(replace X T P) <=> (replace X T Q)]
  X T [T1 = T2] -> [(replace-h X T T1) = (replace-h X T T2)]
  X T [F | Y] -> [F | (map (/. Z (replace-h X T Z)) Y)]   where (atomic? [F | Y])
  _ _ P -> P)
  
(define replace-h
    {term --> term --> term --> term}
    X T X -> T
    X T [F | Y] -> [F | (map (/. Z (replace-h X T Z)) Y)]
     _ _ Y -> Y)

(define replace*
   {term --> term --> prop --> prop}
   S T [all X P] -> [all X P]            where (capture? S X T)
   S T [exists X P] -> [exists X P]       where (capture? S X T)
   S T [all Y P]  -> [all Y (replace* S T P)]
   S T [exists Y P] -> [exists Y (replace* S T P)]
   S T [~ P] ->   [~ (replace* S T P)]
   S T [P v Q] -> [(replace* S T P) v (replace* S T Q)]
   S T [P & Q]  -> [(replace* S T P) & (replace* S T Q)]
   S T [P => Q] -> [(replace* S T P) => (replace* S T Q)]
   S T [P <=> Q] -> [(replace* S T P) <=> (replace* S T Q)]
   S T [T1 = T2] -> [(replace-h S T T1) = (replace-h S T T2)]
   X T [F | Y] -> [F | (map (/. Z (replace-h X T Z)) Y)]   where (atomic? [F | Y])
    _ _ P -> P) 
   
(define capture?
  {term --> term --> term --> boolean}
   S T X -> (and (= (occurrences X S) 0) (= (occurrences X T) 0))) )