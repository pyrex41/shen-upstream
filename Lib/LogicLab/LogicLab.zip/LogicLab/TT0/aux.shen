(define exchange
  {number --> number --> (list A) --> (list A)}
   M N X -> (exchange-h M N X)   where (and (integer? M)
                                            (> M 0)
                                            (integer? N)
                                            (> N 0)
                                            (>= (length X) M)
                                            (>= (length X) N))
   _ _ X -> X)

(define exchange-h 
  {number --> number --> (list A) --> (list A)}
   M N X -> X     where (or (= M 0) (= N 0))
   M N X -> X     where (or (> M (length X)) (> N (length X)))
   1 N [X | Y] -> (let Z (nth N [X | Y])
                            [Z | (insert-nth X (- N 1) Y)])
   M 1 [X | Y] -> (let Z (nth M [X | Y])
                            [Z | (insert-nth X (- M 1) Y)])
   M N [X | Y] -> [X | (exchange-h (- M 1) (- N 1) Y)])

(define remove-nth
  {number --> (list A) --> (list A)}
  N X -> X  	where (not (natural? N))
  _ [] -> []
  1 [_ | Y] -> Y
  N [X | Y] -> [X | (remove-nth (- N 1) Y)])

(define insert-nth
  {A --> number --> (list A) --> (list A)}
   X 1 [_ | Y] -> [X | Y]
   X N [Y | Z] -> [Y | (insert-nth X (- N 1) Z)]) 
   
(define fresh?
  {A --> B --> boolean}
   X Y -> (= (occurrences X Y) 0)) 
   
(define atomic?
   {type --> boolean}
    X -> (every? (/. Y (fresh? Y X)) [v ~ => & all exists]))

(define replace
   {variable --> term --> type --> type}
  X T [all X : A P] -> [all X : A P]
  X T [exists X : A P] -> [exists X : A P]
  X T [all Y : A P]  -> [all Y : A (replace X T P)]
  X T [exists Y : A P] -> [exists Y : A (replace X T P)]
  X T [~ P] -> [~ (replace X T P)]
  X T [P v Q] -> [(replace X T P) v (replace X T Q)]
  X T [P & Q] -> [(replace X T P) & (replace X T Q)]
  X T [P --> Q] -> [(replace X T P) --> (replace X T Q)]
  X T [F | Y] -> [F | (map (/. Z (replace-h X T Z)) Y)]   where (atomic? [F | Y])
  _ _ P -> P)
  
(define replace-h
    {term --> term --> term --> term}
    X T X -> T
    X T [F | Y] -> [F | (map (/. Z (replace-h X T Z)) Y)]
     _ _ Y -> Y)   